export interface IProduto {
    titulo: string;
    imagem?: string;
    descricao: string;
    quantidadeEstoque: number;
    preco: number;
}